#ifndef __TRACE_H_
#define __TRACE_H_

void trace(const LPWSTR format, ...);

#endif

